#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/opt/opscode/embedded/lib"
XSLT_LIBS="-lxslt -L/opt/opscode/embedded/lib -L/opt/opscode/embedded/lib -lxml2 -L/opt/opscode/embedded/lib -lz -L/opt/opscode/embedded/lib -liconv -lm -lm"
XSLT_INCLUDEDIR="-I/opt/opscode/embedded/include"
MODULE_VERSION="xslt-1.1.26"
