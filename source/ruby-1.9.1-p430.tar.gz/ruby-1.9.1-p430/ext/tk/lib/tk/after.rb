#
#   tk/after.rb : methods for Tcl/Tk after command
#
#   $Id: after.rb 11708 2007-02-12 23:01:19Z shyouhei $
#
require 'tk/timer'
