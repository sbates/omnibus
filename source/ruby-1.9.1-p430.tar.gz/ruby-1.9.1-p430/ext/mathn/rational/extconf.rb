require "mkmf"

create_makefile "mathn/rational"
